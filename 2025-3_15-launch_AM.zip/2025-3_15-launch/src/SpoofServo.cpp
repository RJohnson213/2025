#include "SpoofServo.hh"

SpoofServo::SpoofServo() {
  currentAngle = 0;
}

void SpoofServo::setAngle(float angle) {
  currentAngle = angle;
  // Simulate setting the angle
}
