/**
 * BZZT!
*/
#ifndef BZZT_HH
#define BZZT_HH

#define BZZT 7

void bzzt(int bzzBzzCount);
void longBzzt(int bzzBzzCount);

#endif //BZZT_HH