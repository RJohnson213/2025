#include "ServoInterface.hh"

ServoInterface::ServoInterface() {
  // Initialize the servo object if needed
}
